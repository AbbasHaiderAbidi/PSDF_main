
<!DOCTYPE html>

<html class="full">
    <head>

        <title>Administrator</title>
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <link rel="stylesheet" href="../css/main.css">
       <link rel="stylesheet" href="../css/fotorama.css">
        <meta name="viewport" content="width=device-width, intial-scale=1, user-scalable=no">
        <script src="../JQuery/jquery-3.1.0.min.js"></script>
        <script src="../js/bootstrap.min.js"></script>
        <script src="../js/fotorama.js"></script>
    </head>
    <body>
        <div class="container-fluid">
           