
<div class="col-md-2">
    <?php include 'widgets/cart.php';?><hr>
    <?php
    include 'widgets/recent.php';
    ?>

</div>