<div class="col-md-2">
    <?php
    include 'widgets/filters.php';
    ?></div>